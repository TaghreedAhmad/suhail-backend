export type Verdict = 'authentic' | 'suspicious' | 'inconclusive' | 'likely_fake'
export interface Segment { start: number; end: number; note: string }
export interface Report {
  id: string; filename: string; media_type: 'image' | 'video' | 'audio'
  created_at: string; verdict: Verdict; authenticity_score: number; certainty: number
  status: string; reasons?: string[]; recommendations?: string[]; segments?: Segment[]
  model_version?: string
}
export interface Stats { total: number; authentic: number; suspicious: number; inconclusive: number; weekly?: number[] }
