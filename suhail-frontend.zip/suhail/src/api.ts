import type { Report, Stats } from './types'
// عدّل المسارات هنا فقط لتطابق FastAPI لديك
const BASE = import.meta.env.VITE_API_URL ?? '/api'
export const EP = { stats: '/stats', reports: '/reports', analyze: '/analyze', feedback: '/feedback', health: '/health' }

async function req<T>(path: string, init?: RequestInit): Promise<T> {
  const r = await fetch(BASE + path, init)
  if (!r.ok) throw new Error(`خطأ ${r.status}: تعذّر الاتصال بالخادم`)
  return r.json() as Promise<T>
}
export const api = {
  stats: () => req<Stats>(EP.stats),
  reports: () => req<Report[]>(EP.reports),
  report: (id: string) => req<Report>(`${EP.reports}/${id}`),
  health: () => req<{ status: string }>(EP.health),
  feedback: (b: Record<string, unknown>) =>
    req<unknown>(EP.feedback, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b) }),
  analyze: (file: File, onProgress: (p: number) => void) =>
    new Promise<Report>((res, rej) => {
      const x = new XMLHttpRequest(); const fd = new FormData(); fd.append('file', file)
      x.open('POST', BASE + EP.analyze)
      x.upload.onprogress = e => e.lengthComputable && onProgress(Math.round((e.loaded / e.total) * 100))
      x.onload = () => (x.status < 300 ? res(JSON.parse(x.responseText)) : rej(new Error('فشل التحليل')))
      x.onerror = () => rej(new Error('تعذّر الاتصال بالخادم'))
      x.send(fd)
    }),
}
